INSTALANDO O CONECTOR DE MYSL

pip install mysql-connector-python



ATUALIZANDO O CONECTOR

pip install mysql-connector-python --upgrade



DOCUMENTAÇÃO CONECTOR

https://dev.mysql.com/doc/connector-python/en/connector-python-introduction.html


INSTALANDO A BIBLIOTECA PARA TRABALHAR COM ARQUIVOS .env

pip install python-dotenv



INSTALANDO A BIBLIOTECA DO PSUTIL 

pip install psutil